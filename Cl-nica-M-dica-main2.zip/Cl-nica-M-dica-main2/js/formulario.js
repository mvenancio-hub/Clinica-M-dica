const formulario = document.querySelector("#form-contato");

if (formulario) {
    formulario.addEventListener("submit", (evento) => {
        evento.preventDefault();

        const botao = formulario.querySelector("button[type='submit']");
        botao.textContent = "Mensagem enviada!";
        botao.disabled = true;
        formulario.reset();
    });
}
