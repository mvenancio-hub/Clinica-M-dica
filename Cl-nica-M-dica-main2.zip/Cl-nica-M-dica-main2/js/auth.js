const formLogin = document.querySelector("#form-login");
const dialogoRecuperacao = document.querySelector("#dialogo-recuperacao");
const formRecuperacao = document.querySelector("#form-recuperacao");
const campoEmail = document.querySelector("#email");
const campoEmailRecuperacao = document.querySelector("#email-recuperacao");

if (formLogin) {
    formLogin.addEventListener("submit", (evento) => {
        evento.preventDefault();
        sessionStorage.setItem("vitacare-email", campoEmail.value.trim());
        window.location.href = "bem-vindo.html";
    });
}

if (dialogoRecuperacao && campoEmailRecuperacao) {
    document.querySelector("#abrir-recuperacao").addEventListener("click", () => {
        campoEmailRecuperacao.value = campoEmail.value.trim();
        dialogoRecuperacao.showModal();
        campoEmailRecuperacao.focus();
    });

    document.querySelector("[data-fechar-dialogo]").addEventListener("click", () => {
        dialogoRecuperacao.close();
    });
}

if (formRecuperacao) {
    formRecuperacao.addEventListener("submit", (evento) => {
        evento.preventDefault();
        document.querySelector("#mensagem-recuperacao").textContent =
            "Este protótipo não está conectado a um serviço de e-mail. Nenhuma mensagem foi enviada.";
    });
}

const nomeUsuario = document.querySelector("#nome-usuario");
const botaoSair = document.querySelector("#botao-sair");

if (nomeUsuario) {
    const email = sessionStorage.getItem("vitacare-email");

    if (!email) {
        window.location.replace("login.html");
    } else {
        const nome = email.split("@")[0]
            .replace(/[._-]+/g, " ")
            .trim()
            .replace(/\b\p{L}/gu, (letra) => letra.toLocaleUpperCase("pt-BR"));
        nomeUsuario.textContent = nome || "Paciente";
    }
}

if (botaoSair) {
    botaoSair.addEventListener("click", () => {
        sessionStorage.removeItem("vitacare-email");
        window.location.href = "login.html";
    });
}
